import * as React from 'react';
import { Text, View, StyleSheet,Pressable} from 'react-native';
import Constants from 'expo-constants';

export default function Operacao(props){
  return(
    <View>
    <Pressable style={style.botao} >
    <Text>{props.nome}</Text>
    </Pressable>
    </View>
  );
}
const style = StyleSheet.create ({
  botao: {

            backgroundColor: 'blue',
            padding: 20,
            margin: 50,
            alignItems: 'center'
  }
})